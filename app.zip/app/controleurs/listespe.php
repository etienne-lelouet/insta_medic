<?php
require 'modele/listespe.php';

$res=listespe();

require 'vue/listespecialites.php';

?>
