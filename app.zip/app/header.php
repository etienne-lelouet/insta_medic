    <header class="cellHeader">
        <div class="container-fluid">
            <div class="row floflo">
                <div class="col-xs-12 col-lg-12">
                    <div class="cell-logo">
			            <a href="index.php">
                            <img src="img/logo.png" alt="logo">
                        </a>
                        <h1>Clinique</h1>
                        <h1>Geoffroy Saint-Hilaire </h1>
                    </div>
                    <div class="cellEspacePerso">
                        <h3> MON ESPACE PERSONNEL </h3>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

