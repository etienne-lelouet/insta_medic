<?php

require_once 'config.php';

function bdd()
{
    $conn=connexion();
}

?>