<footer>
    <div class="piedDePage">
        <ul>
            <li>Réalisé par <br>
                <a href="https://github.com/flow421">Florian Buis</a>
                <a href="https://github.com/etienne-lelouet">Etienne Le Louët</a>
                <a href="https://github.com/willdow">Willyan Lin</a>
            <li>Les informations personnelles et médicales sont stockées sur un serveur sécurisé</li>
            <li><a href="index.php">Accueil</a></li>
        </ul>
    </div>
</footer>